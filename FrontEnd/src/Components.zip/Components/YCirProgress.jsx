import React from 'react'
import { useEffect, useState } from 'react';
import axios from 'axios';
import { buildStyles, CircularProgressbar } from 'react-circular-progressbar';
export default function YCirProgress() {
    let token = localStorage.getItem('token');
    let [Score, setScore] = useState(0);
    let [marks, setMarks] = useState(0);
    useEffect(() => {
        axios.post('http://localhost:7000/Score', {}, {
            headers: {
                authorization: `Bearer ${token}`,
                'content-type': 'application/json'
            }
        }).then((res) => {
            if (res.data.data === 'Done') {
                let data = parseInt(res.data.message) * 10
                setScore(data);
            }
        }).catch((err) => {
            console.log(err);
        });
    }, []);
    useEffect(() => {
        const interval = setInterval(() => {
            setMarks((prev) => {
                if (prev < Score) {
                    return prev + 1;
                }
                else {
                    clearInterval(interval);
                    return Score;
                }
            })
        }, 20);
        return () => clearInterval(interval);
    }, [Score]);
    return (
        <div className="mc-container-circularbar">
            <div className="mc-container-title">
                <span className="h4">Your Yesterday's Progress:</span>
            </div>
            <div className='mc-circularbar'>
                <CircularProgressbar
                    minValue={0}
                    maxValue={100}
                    value={marks}
                    text={`${marks}%`}
                    styles={buildStyles({
                        textColor: "black",
                        trailColor: "silver",
                        pathColor: "blue",
                        textSize: "16px",
                        pathTransition: "ease",
                        strokeLinecap: "round"
                    })}
                ></CircularProgressbar>
            </div>
        </div>
    )
}
